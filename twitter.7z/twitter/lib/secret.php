<?php
//Consumer Key an Consumer Secret got from twitter app registration.
$consumer_key = 	'rPyGF56KZujZWviGSBpBDdMSk';
$consumer_secret = 'fsn5YYbVrq1dpFnfHlBgTIb2fa2ClNRAXarzZd8eG22A6fU1HD';
$oauthToken = '1943346714-rJCcpDWZojanvnuKPkShEvWM1wPwclqRhyzpLeo';
 $oauthTokenSecret = 'RNcDL0AEHkXZK0ysZdgAA40JjWKTd2QRdVMQiTCKv69no';
?>